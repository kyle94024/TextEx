(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-ce5c4809.js")
    );
  })().catch(console.error);

})();
